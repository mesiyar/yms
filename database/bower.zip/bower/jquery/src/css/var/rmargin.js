define( function() {
	return ( /^margin/ );
} );
